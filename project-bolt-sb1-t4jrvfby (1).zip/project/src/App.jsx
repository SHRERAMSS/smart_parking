import { useState, useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'

// Pages
import Dashboard from './pages/Dashboard'
import ParkingReservation from './pages/ParkingReservation'
import ParkingAvailability from './pages/ParkingAvailability'
import VehicleTracking from './pages/VehicleTracking'
import UserProfile from './pages/UserProfile'
import NotFound from './pages/NotFound'

// Components
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Loading from './components/common/Loading'

function App() {
  const [isAppReady, setIsAppReady] = useState(false)

  useEffect(() => {
    // Simulate app initialization
    const timer = setTimeout(() => {
      setIsAppReady(true)
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  if (!isAppReady) {
    return <Loading />
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/reservations" element={<ParkingReservation />} />
          <Route path="/availability" element={<ParkingAvailability />} />
          <Route path="/vehicles" element={<VehicleTracking />} />
          <Route path="/profile" element={<UserProfile />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
    </div>
  )
}

export default App