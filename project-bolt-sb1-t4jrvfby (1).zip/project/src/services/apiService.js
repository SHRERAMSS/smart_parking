// Mock data service for frontend demo
const apiDelay = (ms = 1000) => new Promise(resolve => setTimeout(resolve, ms));

const mockApiCall = async (data) => {
  await apiDelay();
  return data;
};

// Vehicle API
export const fetchUserVehicles = async () => {
  return mockApiCall([
    {
      id: 'v1',
      make: 'Tesla',
      model: 'Model 3',
      year: 2022,
      color: 'White',
      licensePlate: 'ABC-1234',
      type: 'Electric',
      imageUrl: 'https://images.pexels.com/photos/12309907/pexels-photo-12309907.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      id: 'v2',
      make: 'Honda',
      model: 'Civic',
      year: 2021,
      color: 'Blue',
      licensePlate: 'XYZ-5678',
      type: 'Standard',
      imageUrl: 'https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  ]);
};

export const saveVehicle = async (vehicleData) => {
  return mockApiCall(vehicleData);
};

export const deleteVehicle = async (vehicleId) => {
  return mockApiCall({ success: true });
};

// Parking API
export const fetchParkingLots = async (filters) => {
  return mockApiCall([
    {
      id: 'p1',
      name: 'Downtown Parking Garage',
      address: '123 Main St, City Center',
      totalSpots: 50,
      availableSpots: 15,
      pricePerHour: 3.50,
      distance: 0.8,
      coordinates: { x: 30, y: 40 },
      amenities: {
        electric: true,
        covered: true,
        handicap: true,
        security: true
      },
      imageUrl: 'https://images.pexels.com/photos/3004538/pexels-photo-3004538.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      id: 'p2',
      name: 'Central Mall Parking',
      address: '456 Market Ave, Shopping District',
      totalSpots: 200,
      availableSpots: 42,
      pricePerHour: 2.75,
      distance: 1.2,
      coordinates: { x: 60, y: 30 },
      amenities: {
        electric: false,
        covered: true,
        handicap: true,
        security: true
      },
      imageUrl: 'https://images.pexels.com/photos/1687789/pexels-photo-1687789.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      id: 'p3',
      name: 'Stadium Parking',
      address: '789 Sports Blvd, Entertainment District',
      totalSpots: 300,
      availableSpots: 120,
      pricePerHour: 5.00,
      distance: 2.5,
      coordinates: { x: 40, y: 70 },
      amenities: {
        electric: true,
        covered: false,
        handicap: true,
        security: true
      },
      imageUrl: 'https://images.pexels.com/photos/1000633/pexels-photo-1000633.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  ]);
};

// Event API
export const fetchEvents = async () => {
  return mockApiCall([
    {
      id: 'e1',
      name: 'Summer Music Festival',
      location: 'City Park Amphitheater',
      date: 'Sat, Jun 15, 2023',
      time: '4:00 PM - 11:00 PM',
      type: 'Concert',
      imageUrl: 'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      availableSpots: 45
    },
    {
      id: 'e2',
      name: 'International Food Festival',
      location: 'Downtown Plaza',
      date: 'Sun, Jun 23, 2023',
      time: '11:00 AM - 8:00 PM',
      type: 'Festival',
      imageUrl: 'https://images.pexels.com/photos/5865442/pexels-photo-5865442.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      availableSpots: 78
    },
    {
      id: 'e3',
      name: 'Basketball Championship',
      location: 'City Arena',
      date: 'Fri, Jun 28, 2023',
      time: '7:00 PM - 10:00 PM',
      type: 'Sports',
      imageUrl: 'https://images.pexels.com/photos/945471/pexels-photo-945471.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      availableSpots: 120
    }
  ]);
};

// Reservation API
export const createReservation = async (reservationData) => {
  return mockApiCall({
    id: `r${Date.now()}`,
    ...reservationData,
    status: 'confirmed'
  });
};

// Statistics API
export const fetchParkingStatistics = async () => {
  return mockApiCall({
    totalReservations: 12,
    availableSpots: 248,
    totalVehicles: 2,
    popularLocations: [
      'Downtown Parking Garage',
      'Central Mall Parking',
      'Stadium Parking'
    ]
  });
};

// User API
export const updatePassword = async (data) => {
  return mockApiCall({ success: true });
};

export const fetchUserProfile = async (userId) => {
  return mockApiCall({
    id: userId,
    name: 'John Doe',
    email: 'john.doe@example.com',
    phone: '+1 (555) 123-4567',
    address: '123 Main St, Cityville, ST 12345',
    paymentMethods: [
      {
        id: 'pm1',
        type: 'credit',
        last4: '4242',
        expiry: '12/24'
      }
    ],
    reservationHistory: [
      {
        id: 'r1',
        date: '2023-06-01',
        location: 'Downtown Parking Garage',
        duration: '2 hours',
        amount: 7.00
      }
    ]
  });
};

export const updateUserProfile = async (profileData) => {
  return mockApiCall(profileData);
};

// Payment API
export const addPaymentMethod = async (paymentMethodData) => {
  return mockApiCall(paymentMethodData);
};

export const deletePaymentMethod = async (paymentMethodId) => {
  return mockApiCall({ success: true });
};