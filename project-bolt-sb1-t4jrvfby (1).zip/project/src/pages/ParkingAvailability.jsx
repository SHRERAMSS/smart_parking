import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { FaFilter, FaMapMarkedAlt, FaListUl } from 'react-icons/fa'
import PageHeader from '../components/common/PageHeader'
import Loading from '../components/common/Loading'
import Alert from '../components/common/Alert'
import ParkingMap from '../components/ParkingMap'
import ParkingLotCard from '../components/ParkingLotCard'
import { fetchParkingLots } from '../services/apiService'

const ParkingAvailability = () => {
  const [loading, setLoading] = useState(true)
  const [parkingLots, setParkingLots] = useState([])
  const [error, setError] = useState('')
  const [viewMode, setViewMode] = useState('map') // 'map' or 'list'
  const [filters, setFilters] = useState({
    onlyAvailable: true,
    maxDistance: 10, // km
    priceRange: [0, 50], // dollars
    amenities: {
      electric: false,
      covered: false,
      handicap: false,
      security: false
    }
  })
  const [isFilterOpen, setIsFilterOpen] = useState(false)
  
  useEffect(() => {
    const getParkingLots = async () => {
      try {
        const lotsData = await fetchParkingLots(filters)
        setParkingLots(lotsData)
      } catch (err) {
        console.error('Error fetching parking lots:', err)
        setError('Failed to load parking availability. Please try again later.')
      } finally {
        setLoading(false)
      }
    }
    
    getParkingLots()
  }, [filters])
  
  const toggleFilter = () => {
    setIsFilterOpen(!isFilterOpen)
  }
  
  const handleFilterChange = (key, value) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }))
  }
  
  const handleAmenityChange = (amenity) => {
    setFilters(prev => ({
      ...prev,
      amenities: {
        ...prev.amenities,
        [amenity]: !prev.amenities[amenity]
      }
    }))
  }
  
  if (loading) {
    return <Loading />
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <PageHeader 
          title="Parking Availability"
          description="Find and reserve available parking spots in real-time"
        />
        
        {error && <Alert type="error" message={error} />}
        
        <div className="flex justify-between items-center mb-6">
          <button 
            onClick={toggleFilter}
            className="flex items-center space-x-2 text-primary-500 hover:text-primary-600"
          >
            <FaFilter />
            <span>Filters</span>
          </button>
          
          <div className="flex space-x-2 bg-neutral-100 p-1 rounded-lg">
            <button
              onClick={() => setViewMode('map')}
              className={`px-3 py-1 rounded-md flex items-center space-x-1 ${
                viewMode === 'map' ? 'bg-white shadow-sm' : 'text-neutral-600'
              }`}
            >
              <FaMapMarkedAlt size={14} />
              <span>Map</span>
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`px-3 py-1 rounded-md flex items-center space-x-1 ${
                viewMode === 'list' ? 'bg-white shadow-sm' : 'text-neutral-600'
              }`}
            >
              <FaListUl size={14} />
              <span>List</span>
            </button>
          </div>
        </div>
        
        {isFilterOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-white rounded-xl shadow-md p-6 mb-6"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div>
                <h3 className="text-neutral-800 font-medium mb-3">Availability</h3>
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={filters.onlyAvailable}
                    onChange={() => handleFilterChange('onlyAvailable', !filters.onlyAvailable)}
                    className="h-4 w-4 text-primary-500 border-neutral-300 rounded"
                  />
                  <span>Show only available spots</span>
                </label>
              </div>
              
              <div>
                <h3 className="text-neutral-800 font-medium mb-3">Distance</h3>
                <input
                  type="range"
                  min="1"
                  max="20"
                  value={filters.maxDistance}
                  onChange={(e) => handleFilterChange('maxDistance', parseInt(e.target.value))}
                  className="w-full"
                />
                <p className="text-sm text-neutral-600">Max {filters.maxDistance} km</p>
              </div>
              
              <div>
                <h3 className="text-neutral-800 font-medium mb-3">Price Range</h3>
                <div className="flex space-x-2 items-center">
                  <span>${filters.priceRange[0]}</span>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={filters.priceRange[1]}
                    onChange={(e) => handleFilterChange('priceRange', [filters.priceRange[0], parseInt(e.target.value)])}
                    className="w-full"
                  />
                  <span>${filters.priceRange[1]}</span>
                </div>
              </div>
              
              <div>
                <h3 className="text-neutral-800 font-medium mb-3">Amenities</h3>
                <div className="grid grid-cols-2 gap-2">
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={filters.amenities.electric}
                      onChange={() => handleAmenityChange('electric')}
                      className="h-4 w-4 text-primary-500 border-neutral-300 rounded"
                    />
                    <span>Electric Charging</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={filters.amenities.covered}
                      onChange={() => handleAmenityChange('covered')}
                      className="h-4 w-4 text-primary-500 border-neutral-300 rounded"
                    />
                    <span>Covered Parking</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={filters.amenities.handicap}
                      onChange={() => handleAmenityChange('handicap')}
                      className="h-4 w-4 text-primary-500 border-neutral-300 rounded"
                    />
                    <span>Handicap Access</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={filters.amenities.security}
                      onChange={() => handleAmenityChange('security')}
                      className="h-4 w-4 text-primary-500 border-neutral-300 rounded"
                    />
                    <span>24/7 Security</span>
                  </label>
                </div>
              </div>
            </div>
          </motion.div>
        )}
        
        {viewMode === 'map' ? (
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <ParkingMap height="600px" parkingLots={parkingLots} interactive />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {parkingLots.length > 0 ? (
              parkingLots.map(lot => (
                <ParkingLotCard key={lot.id} parkingLot={lot} />
              ))
            ) : (
              <div className="col-span-3 text-center py-12">
                <p className="text-neutral-500">No parking lots found matching your criteria</p>
              </div>
            )}
          </div>
        )}
      </motion.div>
    </div>
  )
}

export default ParkingAvailability