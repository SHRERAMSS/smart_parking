import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { FaUser, FaKey, FaHistory, FaCreditCard } from 'react-icons/fa'
import { useAuth } from '../context/AuthContext'
import PageHeader from '../components/common/PageHeader'
import Loading from '../components/common/Loading'
import Alert from '../components/common/Alert'
import Tabs from '../components/common/Tabs'
import ProfileForm from '../components/ProfileForm'
import PasswordForm from '../components/PasswordForm'
import PaymentMethodForm from '../components/PaymentMethodForm'
import ReservationHistory from '../components/ReservationHistory'
import { fetchUserProfile } from '../services/apiService'

const UserProfile = () => {
  const { user, logout } = useAuth()
  const [loading, setLoading] = useState(true)
  const [userProfile, setUserProfile] = useState(null)
  const [error, setError] = useState('')
  const [activeTab, setActiveTab] = useState('profile')
  
  useEffect(() => {
    const loadUserProfile = async () => {
      try {
        const profileData = await fetchUserProfile(user.id)
        setUserProfile(profileData)
      } catch (err) {
        console.error('Error fetching user profile:', err)
        setError('Failed to load profile data. Please try again later.')
      } finally {
        setLoading(false)
      }
    }
    
    loadUserProfile()
  }, [user.id])
  
  const handleProfileUpdate = (updatedProfile) => {
    setUserProfile(prev => ({
      ...prev,
      ...updatedProfile
    }))
  }
  
  const handleTabChange = (tab) => {
    setActiveTab(tab)
  }
  
  const tabs = [
    { id: 'profile', label: 'Personal Info', icon: <FaUser /> },
    { id: 'security', label: 'Security', icon: <FaKey /> },
    { id: 'payment', label: 'Payment Methods', icon: <FaCreditCard /> },
    { id: 'history', label: 'Reservation History', icon: <FaHistory /> },
  ]
  
  if (loading) {
    return <Loading />
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <PageHeader 
          title="Your Profile"
          description="Manage your account settings and preferences"
        />
        
        {error && <Alert type="error" message={error} />}
        
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <Tabs 
            tabs={tabs} 
            activeTab={activeTab} 
            onChange={handleTabChange}
          />
          
          <div className="p-6">
            {activeTab === 'profile' && (
              <ProfileForm
                profile={userProfile}
                onUpdate={handleProfileUpdate}
              />
            )}
            
            {activeTab === 'security' && (
              <PasswordForm />
            )}
            
            {activeTab === 'payment' && (
              <PaymentMethodForm
                paymentMethods={userProfile?.paymentMethods || []}
              />
            )}
            
            {activeTab === 'history' && (
              <ReservationHistory
                reservations={userProfile?.reservationHistory || []}
              />
            )}
          </div>
        </div>
        
        <div className="mt-8 text-center">
          <button
            onClick={logout}
            className="text-error hover:text-red-600 font-medium"
          >
            Sign Out
          </button>
        </div>
      </motion.div>
    </div>
  )
}

export default UserProfile