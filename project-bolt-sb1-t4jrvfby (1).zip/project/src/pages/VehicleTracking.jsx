import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { FaPlus, FaEdit, FaTrash } from 'react-icons/fa'
import PageHeader from '../components/common/PageHeader'
import Loading from '../components/common/Loading'
import Alert from '../components/common/Alert'
import Modal from '../components/common/Modal'
import VehicleForm from '../components/VehicleForm'
import VehicleCard from '../components/VehicleCard'
import { fetchUserVehicles, deleteVehicle } from '../services/apiService'

const VehicleTracking = () => {
  const [loading, setLoading] = useState(true)
  const [vehicles, setVehicles] = useState([])
  const [error, setError] = useState('')
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [selectedVehicle, setSelectedVehicle] = useState(null)
  const [isConfirmDeleteOpen, setIsConfirmDeleteOpen] = useState(false)
  const [vehicleToDelete, setVehicleToDelete] = useState(null)
  
  useEffect(() => {
    const loadVehicles = async () => {
      try {
        const vehiclesData = await fetchUserVehicles()
        setVehicles(vehiclesData)
      } catch (err) {
        console.error('Error fetching vehicles:', err)
        setError('Failed to load vehicles. Please try again later.')
      } finally {
        setLoading(false)
      }
    }
    
    loadVehicles()
  }, [])
  
  const handleAddVehicle = () => {
    setSelectedVehicle(null)
    setIsModalOpen(true)
  }
  
  const handleEditVehicle = (vehicle) => {
    setSelectedVehicle(vehicle)
    setIsModalOpen(true)
  }
  
  const handleDeleteClick = (vehicle) => {
    setVehicleToDelete(vehicle)
    setIsConfirmDeleteOpen(true)
  }
  
  const handleConfirmDelete = async () => {
    if (!vehicleToDelete) return
    
    try {
      await deleteVehicle(vehicleToDelete.id)
      setVehicles(vehicles.filter(v => v.id !== vehicleToDelete.id))
      setIsConfirmDeleteOpen(false)
      setVehicleToDelete(null)
    } catch (err) {
      console.error('Error deleting vehicle:', err)
      setError('Failed to delete vehicle. Please try again.')
    }
  }
  
  const handleVehicleSave = (savedVehicle) => {
    if (selectedVehicle) {
      // Editing existing vehicle
      setVehicles(vehicles.map(v => 
        v.id === savedVehicle.id ? savedVehicle : v
      ))
    } else {
      // Adding new vehicle
      setVehicles([...vehicles, savedVehicle])
    }
    
    setIsModalOpen(false)
  }
  
  if (loading) {
    return <Loading />
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <PageHeader 
          title="Vehicle Management"
          description="Track and manage your registered vehicles"
        />
        
        {error && <Alert type="error" message={error} />}
        
        <div className="flex justify-end mb-6">
          <button
            onClick={handleAddVehicle}
            className="btn-primary flex items-center space-x-2"
          >
            <FaPlus size={14} />
            <span>Add Vehicle</span>
          </button>
        </div>
        
        {vehicles.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {vehicles.map(vehicle => (
              <VehicleCard 
                key={vehicle.id} 
                vehicle={vehicle}
                onEdit={() => handleEditVehicle(vehicle)}
                onDelete={() => handleDeleteClick(vehicle)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-white rounded-xl shadow-md">
            <svg
              className="mx-auto h-12 w-12 text-neutral-400"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              aria-hidden="true"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M19 9l-7 7-7-7"
              />
            </svg>
            <h3 className="mt-2 text-lg font-medium text-neutral-900">No vehicles added yet</h3>
            <p className="mt-1 text-neutral-500">Add your first vehicle to start using the parking system.</p>
            <div className="mt-6">
              <button
                onClick={handleAddVehicle}
                className="btn-primary flex items-center space-x-2 mx-auto"
              >
                <FaPlus size={14} />
                <span>Add Vehicle</span>
              </button>
            </div>
          </div>
        )}
        
        <Modal
          isOpen={isModalOpen}
          title={selectedVehicle ? "Edit Vehicle" : "Add New Vehicle"}
          onClose={() => setIsModalOpen(false)}
        >
          <VehicleForm 
            vehicle={selectedVehicle} 
            onSave={handleVehicleSave}
            onCancel={() => setIsModalOpen(false)}
          />
        </Modal>
        
        <Modal
          isOpen={isConfirmDeleteOpen}
          title="Confirm Deletion"
          onClose={() => setIsConfirmDeleteOpen(false)}
        >
          <div className="p-6">
            <p className="mb-4">
              Are you sure you want to delete the vehicle "{vehicleToDelete?.make} {vehicleToDelete?.model}"?
              This action cannot be undone.
            </p>
            <div className="flex justify-end space-x-3">
              <button 
                onClick={() => setIsConfirmDeleteOpen(false)}
                className="btn-secondary"
              >
                Cancel
              </button>
              <button 
                onClick={handleConfirmDelete}
                className="bg-error hover:bg-red-600 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200"
              >
                Delete
              </button>
            </div>
          </div>
        </Modal>
      </motion.div>
    </div>
  )
}

export default VehicleTracking