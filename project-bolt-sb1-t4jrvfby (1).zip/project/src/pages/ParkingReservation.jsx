import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import PageHeader from '../components/common/PageHeader'
import Loading from '../components/common/Loading'
import Alert from '../components/common/Alert'
import EventCard from '../components/EventCard'
import ReservationForm from '../components/ReservationForm'
import { fetchEvents } from '../services/apiService'

const ParkingReservation = () => {
  const [loading, setLoading] = useState(true)
  const [events, setEvents] = useState([])
  const [selectedEvent, setSelectedEvent] = useState(null)
  const [error, setError] = useState('')
  const [searchTerm, setSearchTerm] = useState('')
  
  useEffect(() => {
    const getEvents = async () => {
      try {
        const eventsData = await fetchEvents()
        setEvents(eventsData)
      } catch (err) {
        console.error('Error fetching events:', err)
        setError('Failed to load events. Please try again later.')
      } finally {
        setLoading(false)
      }
    }
    
    getEvents()
  }, [])
  
  const filteredEvents = events.filter(event => 
    event.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    event.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
    event.type.toLowerCase().includes(searchTerm.toLowerCase())
  )
  
  const handleSelectEvent = (event) => {
    setSelectedEvent(event)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }
  
  const handleBackToEvents = () => {
    setSelectedEvent(null)
  }
  
  if (loading) {
    return <Loading />
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <PageHeader 
          title={selectedEvent ? `Reserve Parking: ${selectedEvent.name}` : "Parking Reservations"}
          description={selectedEvent 
            ? `Select a parking spot for ${selectedEvent.date} at ${selectedEvent.location}`
            : "Book parking spots for upcoming events and special occasions"
          }
        />
        
        {error && <Alert type="error" message={error} />}
        
        {selectedEvent ? (
          <ReservationForm 
            event={selectedEvent} 
            onBack={handleBackToEvents}
          />
        ) : (
          <>
            <div className="mb-8">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search events by name, location, or type..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="input-field pl-10"
                />
                <svg 
                  className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-neutral-400"
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 20 20" 
                  fill="currentColor"
                >
                  <path 
                    fillRule="evenodd" 
                    d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" 
                    clipRule="evenodd" 
                  />
                </svg>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredEvents.length > 0 ? (
                filteredEvents.map(event => (
                  <EventCard 
                    key={event.id} 
                    event={event} 
                    onSelect={() => handleSelectEvent(event)}
                  />
                ))
              ) : (
                <div className="col-span-3 text-center py-12">
                  <p className="text-neutral-500">No events found matching "{searchTerm}"</p>
                </div>
              )}
            </div>
          </>
        )}
      </motion.div>
    </div>
  )
}

export default ParkingReservation