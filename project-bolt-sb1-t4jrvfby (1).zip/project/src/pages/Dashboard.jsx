import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FaParking, FaCalendarAlt, FaCar, FaMapMarkerAlt } from 'react-icons/fa'
import ReservationCard from '../components/ReservationCard'
import ParkingMap from '../components/ParkingMap'
import Loading from '../components/common/Loading'
import { fetchParkingStatistics } from '../services/apiService'

const Dashboard = () => {
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({
    totalReservations: 0,
    availableSpots: 0,
    totalVehicles: 0,
    popularLocations: []
  })

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        const parkingStats = await fetchParkingStatistics()
        setStats(parkingStats)
      } catch (error) {
        console.error('Error loading dashboard data:', error)
      } finally {
        setLoading(false)
      }
    }
    
    loadDashboardData()
  }, [])
  
  if (loading) {
    return <Loading />
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-neutral-900">
            Welcome to SmartPark
          </h1>
          <p className="text-neutral-600 mt-2">
            Find and reserve parking spots easily
          </p>
        </header>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard 
            icon={<FaCalendarAlt className="text-primary-500" />} 
            title="Available Events" 
            value={stats.totalReservations}
            link="/reservations"
          />
          <StatCard 
            icon={<FaParking className="text-secondary-500" />} 
            title="Available Spots" 
            value={stats.availableSpots}
            link="/availability"
          />
          <StatCard 
            icon={<FaCar className="text-accent-500" />} 
            title="Registered Vehicles" 
            value={stats.totalVehicles}
            link="/vehicles"
          />
          <StatCard 
            icon={<FaMapMarkerAlt className="text-warning" />} 
            title="Popular Locations" 
            value={stats.popularLocations.length}
            link="/availability"
          />
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-md p-6 h-full">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-neutral-900">Parking Map</h2>
                <Link to="/availability" className="text-primary-500 hover:text-primary-600 text-sm font-medium">
                  View all locations
                </Link>
              </div>
              
              <ParkingMap height="400px" />
            </div>
          </div>
          
          <div>
            <div className="bg-white rounded-xl shadow-md p-6 h-full">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-neutral-900">Featured Events</h2>
                <Link to="/reservations" className="text-primary-500 hover:text-primary-600 text-sm font-medium">
                  View all
                </Link>
              </div>
              
              <div className="space-y-4">
                <ReservationCard />
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  )
}

const StatCard = ({ icon, title, value, link }) => {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      transition={{ type: "spring", stiffness: 300 }}
    >
      <Link to={link} className="block">
        <div className="bg-white rounded-xl shadow-md p-6 h-full hover:shadow-lg transition-shadow">
          <div className="flex items-center mb-4">
            <div className="p-3 bg-neutral-100 rounded-lg mr-4">
              {icon}
            </div>
            <h3 className="text-lg font-medium text-neutral-900">{title}</h3>
          </div>
          <p className="text-3xl font-bold text-neutral-800">{value}</p>
        </div>
      </Link>
    </motion.div>
  )
}

export default Dashboard