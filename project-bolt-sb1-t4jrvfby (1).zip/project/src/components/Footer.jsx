import { Link } from 'react-router-dom'
import Logo from './common/Logo'
import { FaFacebook, FaTwitter, FaInstagram, FaLinkedin } from 'react-icons/fa'

const Footer = () => {
  const year = new Date().getFullYear()
  
  return (
    <footer className="bg-white border-t border-neutral-200 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <Logo className="h-6 w-auto" />
            <p className="mt-4 text-sm text-neutral-600">
              Smart Parking System provides intelligent parking solutions for modern cities and venues, making parking hassle-free.
            </p>
            <div className="mt-4 flex space-x-4">
              <a href="#" className="text-neutral-400 hover:text-primary-500">
                <FaFacebook size={18} />
              </a>
              <a href="#" className="text-neutral-400 hover:text-primary-500">
                <FaTwitter size={18} />
              </a>
              <a href="#" className="text-neutral-400 hover:text-primary-500">
                <FaInstagram size={18} />
              </a>
              <a href="#" className="text-neutral-400 hover:text-primary-500">
                <FaLinkedin size={18} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-neutral-800 tracking-wider uppercase">Features</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <Link to="/reservations" className="text-sm text-neutral-600 hover:text-primary-500">
                  Parking Reservations
                </Link>
              </li>
              <li>
                <Link to="/availability" className="text-sm text-neutral-600 hover:text-primary-500">
                  Parking Availability
                </Link>
              </li>
              <li>
                <Link to="/vehicles" className="text-sm text-neutral-600 hover:text-primary-500">
                  Vehicle Management
                </Link>
              </li>
              <li>
                <a href="#" className="text-sm text-neutral-600 hover:text-primary-500">
                  Special Event Parking
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-neutral-800 tracking-wider uppercase">Support</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <a href="#" className="text-sm text-neutral-600 hover:text-primary-500">
                  Help Center
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-neutral-600 hover:text-primary-500">
                  Contact Us
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-neutral-600 hover:text-primary-500">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-neutral-600 hover:text-primary-500">
                  Terms of Service
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-neutral-800 tracking-wider uppercase">Download</h3>
            <p className="mt-4 text-sm text-neutral-600">
              Get our mobile app for a better parking experience.
            </p>
            <div className="mt-4 space-y-2">
              <a href="#" className="block px-4 py-2 bg-black text-white rounded-lg text-sm font-medium flex items-center justify-center hover:bg-neutral-800">
                <svg className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.9 1.4A1 1 0 16 2v20a1 1 0 011.9.6l5.8-10a1 1 0 000-1.2l-5.8-10zM9 9H5c-1.1 0-2 .9-2 2v2c0 1.1.9 2 2 2h4v3c0 .6.4 1 1 1s1-.4 1-1V7c0-.6-.4-1-1-1s-1 .4-1 1v2zm5-7c-.6 0-1 .4-1 1v18c0 .6.4 1 1 1s1-.4 1-1V3c0-.6-.4-1-1-1z"/>
                </svg>
                App Store
              </a>
              <a href="#" className="block px-4 py-2 bg-neutral-900 text-white rounded-lg text-sm font-medium flex items-center justify-center hover:bg-neutral-800">
                <svg className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M3 3.71v16.58a1 1 0 001.71.71l7.3-5.3 7.3 5.3a1 1 0 001.71-.71V3.71a1 1 0 00-1.71-.71L12 8.3 4.71 3a1 1 0 00-1.71.71z"/>
                </svg>
                Play Store
              </a>
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-neutral-200 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-neutral-500">
            &copy; {year} Smart Parking System. All rights reserved.
          </p>
          <p className="text-sm text-neutral-500 mt-4 md:mt-0">
            Made with ❤️ for a better parking experience
          </p>
        </div>
      </div>
    </footer>
  )
}

export default Footer