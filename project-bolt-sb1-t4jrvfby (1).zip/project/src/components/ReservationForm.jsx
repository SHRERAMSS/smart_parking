import { useState } from 'react'
import { motion } from 'framer-motion'
import { FaArrowLeft, FaClock, FaCar, FaMoneyBillWave } from 'react-icons/fa'
import Alert from './common/Alert'
import { createReservation } from '../services/apiService'

const ReservationForm = ({ event, onBack }) => {
  const [reservationData, setReservationData] = useState({
    date: new Date().toISOString().split('T')[0],
    time: '18:00',
    duration: 3,
    vehicle: '',
    paymentMethod: ''
  })
  
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)
  
  // Mock data for demo
  const vehicles = [
    { id: 'v1', name: 'Tesla Model 3 (ABC-1234)' },
    { id: 'v2', name: 'Honda Civic (XYZ-5678)' }
  ]
  
  const paymentMethods = [
    { id: 'p1', name: 'Credit Card (Visa •••• 4242)' },
    { id: 'p2', name: 'Credit Card (Mastercard •••• 5555)' }
  ]
  
  const parkingSpots = [
    { id: 'A-12', type: 'Standard', price: 15, available: true },
    { id: 'A-13', type: 'Standard', price: 15, available: true },
    { id: 'B-05', type: 'Premium', price: 25, available: true },
    { id: 'B-06', type: 'Premium', price: 25, available: true },
    { id: 'C-01', type: 'VIP', price: 40, available: true },
    { id: 'D-10', type: 'Standard', price: 15, available: false }
  ]
  
  const [selectedSpot, setSelectedSpot] = useState(null)
  
  const handleChange = (e) => {
    setReservationData({
      ...reservationData,
      [e.target.name]: e.target.value
    })
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!selectedSpot) {
      setError('Please select a parking spot')
      return
    }
    
    if (!reservationData.vehicle) {
      setError('Please select a vehicle')
      return
    }
    
    if (!reservationData.paymentMethod) {
      setError('Please select a payment method')
      return
    }
    
    setLoading(true)
    setError('')
    
    try {
      const reservation = {
        ...reservationData,
        eventId: event.id,
        spotId: selectedSpot.id,
        price: selectedSpot.price * reservationData.duration
      }
      
      await createReservation(reservation)
      setSuccess(true)
    } catch (err) {
      console.error('Error creating reservation:', err)
      setError('Failed to create reservation. Please try again.')
    } finally {
      setLoading(false)
    }
  }
  
  if (success) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-white rounded-xl shadow-md p-8 text-center"
      >
        <div className="w-16 h-16 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <svg className="h-8 w-8 text-secondary-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h3 className="text-2xl font-bold text-neutral-900 mb-2">Reservation Confirmed!</h3>
        <p className="text-neutral-600 mb-6">
          Your parking spot {selectedSpot.id} has been reserved for {event.name}.
        </p>
        <div className="flex flex-col space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4 justify-center">
          <button 
            onClick={onBack}
            className="btn-secondary"
          >
            Back to Events
          </button>
          <button className="btn-primary">
            View My Reservations
          </button>
        </div>
      </motion.div>
    )
  }

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden">
      <div className="p-6">
        <button 
          onClick={onBack}
          className="flex items-center text-primary-500 hover:text-primary-600 mb-4"
        >
          <FaArrowLeft className="mr-2" />
          <span>Back to events</span>
        </button>
        
        {error && <Alert type="error" message={error} className="mb-4" />}
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit}>
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-neutral-900 mb-2">Event Details</h3>
                <div className="bg-neutral-50 p-4 rounded-lg">
                  <p className="font-medium text-neutral-900">{event.name}</p>
                  <p className="text-neutral-600">{event.location}</p>
                  <p className="text-neutral-600">{event.date} · {event.time}</p>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-neutral-900 mb-2">Select Parking Spot</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {parkingSpots.map(spot => (
                    <button
                      key={spot.id}
                      type="button"
                      disabled={!spot.available}
                      onClick={() => setSelectedSpot(spot)}
                      className={`p-3 rounded-lg border ${
                        !spot.available
                          ? 'bg-neutral-100 border-neutral-200 text-neutral-400 cursor-not-allowed'
                          : selectedSpot?.id === spot.id
                            ? 'bg-primary-50 border-primary-500 text-primary-700'
                            : 'border-neutral-200 hover:border-primary-500'
                      }`}
                    >
                      <div className="font-medium">{spot.id}</div>
                      <div className="text-sm">{spot.type}</div>
                      <div className="text-sm">${spot.price}/hr</div>
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-neutral-900 mb-2">Reservation Details</h3>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="date" className="block text-sm font-medium text-neutral-700">
                      Date
                    </label>
                    <input
                      id="date"
                      name="date"
                      type="date"
                      value={reservationData.date}
                      onChange={handleChange}
                      className="input-field mt-1"
                      required
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="time" className="block text-sm font-medium text-neutral-700">
                      Arrival Time
                    </label>
                    <input
                      id="time"
                      name="time"
                      type="time"
                      value={reservationData.time}
                      onChange={handleChange}
                      className="input-field mt-1"
                      required
                    />
                  </div>
                </div>
                
                <div className="mt-4">
                  <label htmlFor="duration" className="block text-sm font-medium text-neutral-700">
                    Duration (hours)
                  </label>
                  <div className="flex items-center mt-1">
                    <FaClock className="text-neutral-500 mr-2" />
                    <input
                      id="duration"
                      name="duration"
                      type="range"
                      min="1"
                      max="8"
                      value={reservationData.duration}
                      onChange={handleChange}
                      className="flex-grow"
                    />
                    <span className="ml-2 w-8 text-center">{reservationData.duration}h</span>
                  </div>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-neutral-900 mb-2">Vehicle & Payment</h3>
                
                <div className="mb-4">
                  <label htmlFor="vehicle" className="block text-sm font-medium text-neutral-700">
                    Select Vehicle
                  </label>
                  <div className="flex items-center mt-1">
                    <FaCar className="text-neutral-500 mr-2" />
                    <select
                      id="vehicle"
                      name="vehicle"
                      value={reservationData.vehicle}
                      onChange={handleChange}
                      className="input-field flex-grow"
                      required
                    >
                      <option value="">Select a vehicle</option>
                      {vehicles.map(vehicle => (
                        <option key={vehicle.id} value={vehicle.id}>
                          {vehicle.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                
                <div>
                  <label htmlFor="paymentMethod" className="block text-sm font-medium text-neutral-700">
                    Payment Method
                  </label>
                  <div className="flex items-center mt-1">
                    <FaMoneyBillWave className="text-neutral-500 mr-2" />
                    <select
                      id="paymentMethod"
                      name="paymentMethod"
                      value={reservationData.paymentMethod}
                      onChange={handleChange}
                      className="input-field flex-grow"
                      required
                    >
                      <option value="">Select payment method</option>
                      {paymentMethods.map(method => (
                        <option key={method.id} value={method.id}>
                          {method.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
              
              <div className="border-t border-neutral-200 pt-6">
                <button
                  type="submit"
                  disabled={loading}
                  className="btn-primary w-full flex justify-center items-center"
                >
                  {loading ? (
                    <span className="inline-block h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
                  ) : null}
                  Complete Reservation
                </button>
              </div>
            </form>
          </div>
          
          <div>
            <div className="bg-neutral-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-neutral-900 mb-4">Reservation Summary</h3>
              
              <div className="space-y-3 mb-6">
                <div className="flex justify-between">
                  <span className="text-neutral-600">Event:</span>
                  <span className="font-medium">{event.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600">Date:</span>
                  <span>{event.date}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600">Parking Spot:</span>
                  <span>{selectedSpot ? selectedSpot.id : 'Not selected'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600">Duration:</span>
                  <span>{reservationData.duration} hours</span>
                </div>
              </div>
              
              <div className="border-t border-neutral-200 pt-4 mb-4">
                <div className="flex justify-between text-lg font-semibold">
                  <span>Total:</span>
                  <span>${selectedSpot ? (selectedSpot.price * reservationData.duration) : 0}</span>
                </div>
                <p className="text-xs text-neutral-500 mt-1">
                  Includes all taxes and fees
                </p>
              </div>
              
              <div className="bg-primary-50 border border-primary-200 p-3 rounded-lg text-sm text-primary-700">
                <p>Reserve now to guarantee your parking spot for this event!</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ReservationForm