import { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { FaParking, FaCalendarAlt, FaCar, FaUser, FaBars, FaTimes } from 'react-icons/fa'
import Logo from './common/Logo'

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  
  const links = [
    { path: '/', label: 'Dashboard', icon: <FaParking /> },
    { path: '/reservations', label: 'Reservations', icon: <FaCalendarAlt /> },
    { path: '/availability', label: 'Find Parking', icon: <FaParking /> },
    { path: '/vehicles', label: 'Vehicles', icon: <FaCar /> },
  ]
  
  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }
  
  const closeMenu = () => {
    setIsMenuOpen(false)
  }
  
  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex-shrink-0 flex items-center">
            <Logo />
          </div>
          
          {/* Desktop menu */}
          <div className="hidden md:flex items-center space-x-4">
            {links.map(link => (
              <NavLink
                key={link.path}
                to={link.path}
                className={({ isActive }) => `
                  px-3 py-2 rounded-md text-sm font-medium flex items-center space-x-1
                  ${isActive 
                    ? 'text-primary-500 bg-primary-50' 
                    : 'text-neutral-600 hover:text-primary-500 hover:bg-neutral-100'
                  }
                `}
              >
                {link.icon}
                <span>{link.label}</span>
              </NavLink>
            ))}
            
            <div className="ml-2 relative">
              <Link
                to="/profile"
                className="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium text-neutral-600 hover:text-primary-500 hover:bg-neutral-100"
              >
                <div className="w-8 h-8 bg-neutral-200 rounded-full flex items-center justify-center">
                  <FaUser className="text-neutral-600" />
                </div>
                <span>Guest User</span>
              </Link>
            </div>
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={toggleMenu}
              className="p-2 rounded-md text-neutral-500 hover:text-neutral-700 hover:bg-neutral-100 focus:outline-none"
            >
              {isMenuOpen ? <FaTimes size={20} /> : <FaBars size={20} />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="md:hidden bg-white shadow-md"
          >
            <div className="px-2 pt-2 pb-3 space-y-1">
              {links.map(link => (
                <NavLink
                  key={link.path}
                  to={link.path}
                  onClick={closeMenu}
                  className={({ isActive }) => `
                    block px-3 py-2 rounded-md text-base font-medium flex items-center space-x-3
                    ${isActive 
                      ? 'text-primary-500 bg-primary-50' 
                      : 'text-neutral-600 hover:text-primary-500 hover:bg-neutral-100'
                    }
                  `}
                >
                  {link.icon}
                  <span>{link.label}</span>
                </NavLink>
              ))}
              
              <NavLink
                to="/profile"
                onClick={closeMenu}
                className={({ isActive }) => `
                  block px-3 py-2 rounded-md text-base font-medium flex items-center space-x-3
                  ${isActive 
                    ? 'text-primary-500 bg-primary-50' 
                    : 'text-neutral-600 hover:text-primary-500 hover:bg-neutral-100'
                  }
                `}
              >
                <FaUser />
                <span>Profile</span>
              </NavLink>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  )
}

export default Navbar