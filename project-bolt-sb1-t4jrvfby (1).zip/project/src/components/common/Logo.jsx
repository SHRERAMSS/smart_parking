import { Link } from 'react-router-dom'

const Logo = ({ className }) => {
  return (
    <Link to="/" className="flex items-center">
      <div className="flex items-center space-x-2">
        <div className="text-primary-500">
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            viewBox="0 0 24 24" 
            fill="currentColor" 
            className={className || "h-8 w-8"}
          >
            <path d="M3 3h18a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1zm9.9 14h1.7a.6.6 0 0 0 .6-.6v-1.8a.6.6 0 0 0-.6-.6h-2.3a.6.6 0 0 1-.6-.6v-1.8a.6.6 0 0 1 .6-.6H15a.6.6 0 0 0 .6-.6V9a.6.6 0 0 0-.6-.6h-3.6a.6.6 0 0 0-.6.6v7.2c0 .331.269.6.6.6zM10 8a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
          </svg>
        </div>
        <div className="font-bold text-xl text-neutral-900">SmartPark</div>
      </div>
    </Link>
  )
}

export default Logo