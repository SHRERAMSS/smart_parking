import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { FaExclamationCircle, FaCheckCircle, FaInfoCircle, FaExclamationTriangle, FaTimes } from 'react-icons/fa'

const Alert = ({ type = 'info', message, dismissible = true }) => {
  const [isVisible, setIsVisible] = useState(true)
  
  if (!isVisible) return null
  
  const getAlertStyles = () => {
    switch (type) {
      case 'success':
        return {
          bg: 'bg-secondary-50',
          border: 'border-secondary-500',
          text: 'text-secondary-700',
          icon: <FaCheckCircle className="text-secondary-500" />
        }
      case 'error':
        return {
          bg: 'bg-error bg-opacity-10',
          border: 'border-error',
          text: 'text-error',
          icon: <FaExclamationCircle className="text-error" />
        }
      case 'warning':
        return {
          bg: 'bg-warning bg-opacity-10',
          border: 'border-warning',
          text: 'text-warning',
          icon: <FaExclamationTriangle className="text-warning" />
        }
      default: // info
        return {
          bg: 'bg-primary-50',
          border: 'border-primary-500',
          text: 'text-primary-700',
          icon: <FaInfoCircle className="text-primary-500" />
        }
    }
  }
  
  const styles = getAlertStyles()
  
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.3 }}
          className={`${styles.bg} ${styles.text} border-l-4 ${styles.border} p-4 mb-6 rounded-r-lg flex items-start`}
        >
          <div className="flex-shrink-0 mt-0.5 mr-3">{styles.icon}</div>
          <div className="flex-grow">{message}</div>
          {dismissible && (
            <button 
              onClick={() => setIsVisible(false)}
              className="flex-shrink-0 ml-3 text-neutral-500 hover:text-neutral-700 transition-colors"
            >
              <FaTimes />
            </button>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  )
}

export default Alert