import { motion } from 'framer-motion'

const Loading = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-neutral-50">
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ 
          duration: 1.5, 
          repeat: Infinity, 
          ease: "linear" 
        }}
        className="w-16 h-16 border-4 border-primary-200 border-t-primary-500 rounded-full"
      />
      <p className="mt-4 text-neutral-600 font-medium">Loading...</p>
    </div>
  )
}

export default Loading