import { motion } from 'framer-motion'

const Tabs = ({ tabs, activeTab, onChange }) => {
  return (
    <div className="border-b border-neutral-200">
      <nav className="flex overflow-x-auto hide-scrollbar">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onChange(tab.id)}
            className={`relative px-4 py-4 text-sm font-medium flex items-center space-x-2 whitespace-nowrap
              ${activeTab === tab.id
                ? 'text-primary-500'
                : 'text-neutral-500 hover:text-neutral-700'
              }
            `}
          >
            {tab.icon}
            <span>{tab.label}</span>
            
            {activeTab === tab.id && (
              <motion.div
                layoutId="activeTabIndicator"
                className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary-500"
                initial={false}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              />
            )}
          </button>
        ))}
      </nav>
    </div>
  )
}

export default Tabs