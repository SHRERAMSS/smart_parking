import { useState } from 'react'
import { FaPlus, FaCreditCard, FaTrash } from 'react-icons/fa'
import Alert from './common/Alert'
import Modal from './common/Modal'
import { addPaymentMethod, deletePaymentMethod } from '../services/apiService'

const PaymentMethodForm = ({ paymentMethods: initialPaymentMethods = [] }) => {
  // For demo purposes
  const demoPaymentMethods = initialPaymentMethods.length > 0 ? initialPaymentMethods : [
    { id: 'p1', type: 'visa', last4: '4242', expiryMonth: '12', expiryYear: '2024', isDefault: true },
    { id: 'p2', type: 'mastercard', last4: '5555', expiryMonth: '08', expiryYear: '2025', isDefault: false }
  ]
  
  const [paymentMethods, setPaymentMethods] = useState(demoPaymentMethods)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [paymentMethodToDelete, setPaymentMethodToDelete] = useState(null)
  
  const [formData, setFormData] = useState({
    cardNumber: '',
    cardholderName: '',
    expiryMonth: '',
    expiryYear: '',
    cvv: '',
    isDefault: false
  })
  
  const handleChange = (e) => {
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value
    setFormData({
      ...formData,
      [e.target.name]: value
    })
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    
    // Simple validation
    if (!formData.cardNumber || !formData.cardholderName || !formData.expiryMonth || !formData.expiryYear || !formData.cvv) {
      setError('All fields are required')
      return
    }
    
    setLoading(true)
    setError('')
    
    try {
      // In a real app, this would be an API call to securely store payment info
      const newPaymentMethod = await addPaymentMethod({
        ...formData,
        id: `p${Date.now()}`, // For demo
        type: getCardType(formData.cardNumber),
        last4: formData.cardNumber.slice(-4)
      })
      
      if (formData.isDefault) {
        // Update other cards to not be default
        setPaymentMethods(prev => 
          prev.map(pm => ({...pm, isDefault: false}))
        )
      }
      
      setPaymentMethods(prev => [...prev, newPaymentMethod])
      setIsModalOpen(false)
      setSuccess(true)
      
      // Reset form
      setFormData({
        cardNumber: '',
        cardholderName: '',
        expiryMonth: '',
        expiryYear: '',
        cvv: '',
        isDefault: false
      })
    } catch (err) {
      console.error('Error adding payment method:', err)
      setError('Failed to add payment method. Please try again.')
    } finally {
      setLoading(false)
    }
  }
  
  const handleDeleteClick = (paymentMethod) => {
    setPaymentMethodToDelete(paymentMethod)
    setIsDeleteModalOpen(true)
  }
  
  const handleConfirmDelete = async () => {
    if (!paymentMethodToDelete) return
    
    try {
      await deletePaymentMethod(paymentMethodToDelete.id)
      setPaymentMethods(paymentMethods.filter(pm => pm.id !== paymentMethodToDelete.id))
      setIsDeleteModalOpen(false)
      setPaymentMethodToDelete(null)
    } catch (err) {
      console.error('Error deleting payment method:', err)
      setError('Failed to delete payment method')
    }
  }
  
  const handleSetDefault = async (id) => {
    try {
      setPaymentMethods(paymentMethods.map(pm => ({
        ...pm,
        isDefault: pm.id === id
      })))
      
      // In a real app, call API here
    } catch (err) {
      console.error('Error setting default payment method:', err)
    }
  }
  
  // Helper to determine card type from number
  const getCardType = (number) => {
    const firstDigit = number[0]
    if (firstDigit === '4') return 'visa'
    if (firstDigit === '5') return 'mastercard'
    if (firstDigit === '3') return 'amex'
    return 'generic'
  }
  
  // Get card logo based on type
  const getCardLogo = (type) => {
    switch (type) {
      case 'visa':
        return '💳 Visa'
      case 'mastercard':
        return '💳 Mastercard'
      case 'amex':
        return '💳 Amex'
      default:
        return '💳 Card'
    }
  }

  return (
    <div>
      {error && <Alert type="error" message={error} className="mb-4" />}
      {success && <Alert type="success" message="Payment method added successfully!" className="mb-4" />}
      
      <div className="mb-4">
        <button
          onClick={() => setIsModalOpen(true)}
          className="btn-primary flex items-center space-x-2"
        >
          <FaPlus size={14} />
          <span>Add Payment Method</span>
        </button>
      </div>
      
      {paymentMethods.length > 0 ? (
        <div className="space-y-4">
          {paymentMethods.map(method => (
            <div 
              key={method.id}
              className={`border rounded-lg p-4 flex items-center justify-between ${
                method.isDefault ? 'border-primary-500 bg-primary-50' : 'border-neutral-200'
              }`}
            >
              <div className="flex items-center">
                <div className="mr-4 text-2xl">
                  {getCardLogo(method.type)}
                </div>
                <div>
                  <p className="font-medium">
                    {method.type.charAt(0).toUpperCase() + method.type.slice(1)} •••• {method.last4}
                  </p>
                  <p className="text-sm text-neutral-500">
                    Expires {method.expiryMonth}/{method.expiryYear}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                {!method.isDefault && (
                  <button
                    onClick={() => handleSetDefault(method.id)}
                    className="text-sm text-primary-500 hover:text-primary-600"
                  >
                    Set as default
                  </button>
                )}
                <button
                  onClick={() => handleDeleteClick(method)}
                  className="text-error hover:text-red-700"
                >
                  <FaTrash size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8 bg-neutral-50 rounded-lg border border-neutral-200">
          <FaCreditCard className="mx-auto text-neutral-400 text-3xl mb-2" />
          <p className="text-neutral-600">No payment methods added yet</p>
        </div>
      )}
      
      <Modal
        isOpen={isModalOpen}
        title="Add Payment Method"
        onClose={() => setIsModalOpen(false)}
      >
        <form onSubmit={handleSubmit} className="p-6">
          <div className="mb-4">
            <label htmlFor="cardNumber" className="block text-sm font-medium text-neutral-700">
              Card Number
            </label>
            <input
              id="cardNumber"
              name="cardNumber"
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength="16"
              value={formData.cardNumber}
              onChange={handleChange}
              className="input-field mt-1"
              placeholder="1234 5678 9012 3456"
              required
            />
          </div>
          
          <div className="mb-4">
            <label htmlFor="cardholderName" className="block text-sm font-medium text-neutral-700">
              Cardholder Name
            </label>
            <input
              id="cardholderName"
              name="cardholderName"
              type="text"
              value={formData.cardholderName}
              onChange={handleChange}
              className="input-field mt-1"
              placeholder="John Doe"
              required
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label htmlFor="expiryMonth" className="block text-sm font-medium text-neutral-700">
                Expiry Month
              </label>
              <select
                id="expiryMonth"
                name="expiryMonth"
                value={formData.expiryMonth}
                onChange={handleChange}
                className="input-field mt-1"
                required
              >
                <option value="">Month</option>
                {Array.from({ length: 12 }, (_, i) => {
                  const month = i + 1
                  return (
                    <option key={month} value={month.toString().padStart(2, '0')}>
                      {month.toString().padStart(2, '0')}
                    </option>
                  )
                })}
              </select>
            </div>
            
            <div>
              <label htmlFor="expiryYear" className="block text-sm font-medium text-neutral-700">
                Expiry Year
              </label>
              <select
                id="expiryYear"
                name="expiryYear"
                value={formData.expiryYear}
                onChange={handleChange}
                className="input-field mt-1"
                required
              >
                <option value="">Year</option>
                {Array.from({ length: 10 }, (_, i) => {
                  const year = new Date().getFullYear() + i
                  return (
                    <option key={year} value={year.toString()}>
                      {year}
                    </option>
                  )
                })}
              </select>
            </div>
          </div>
          
          <div className="mb-6">
            <label htmlFor="cvv" className="block text-sm font-medium text-neutral-700">
              CVV
            </label>
            <input
              id="cvv"
              name="cvv"
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength="4"
              value={formData.cvv}
              onChange={handleChange}
              className="input-field mt-1 w-24"
              placeholder="123"
              required
            />
          </div>
          
          <div className="mb-6">
            <label className="flex items-center">
              <input
                type="checkbox"
                name="isDefault"
                checked={formData.isDefault}
                onChange={handleChange}
                className="h-4 w-4 text-primary-500 border-neutral-300 rounded"
              />
              <span className="ml-2 text-sm text-neutral-700">
                Set as default payment method
              </span>
            </label>
          </div>
          
          <div className="flex justify-end">
            <button 
              type="submit"
              disabled={loading}
              className="btn-primary flex items-center space-x-2"
            >
              {loading ? (
                <span className="inline-block h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
              ) : (
                <FaCreditCard size={14} />
              )}
              <span>Add Card</span>
            </button>
          </div>
        </form>
      </Modal>
      
      <Modal
        isOpen={isDeleteModalOpen}
        title="Confirm Deletion"
        onClose={() => setIsDeleteModalOpen(false)}
      >
        <div className="p-6">
          <p className="mb-4">
            Are you sure you want to delete this payment method?
            {paymentMethodToDelete?.isDefault && (
              <span className="block text-error mt-2 font-medium">
                This is your default payment method.
              </span>
            )}
          </p>
          <div className="flex justify-end space-x-3">
            <button 
              onClick={() => setIsDeleteModalOpen(false)}
              className="btn-secondary"
            >
              Cancel
            </button>
            <button 
              onClick={handleConfirmDelete}
              className="bg-error hover:bg-red-600 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200"
            >
              Delete
            </button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default PaymentMethodForm