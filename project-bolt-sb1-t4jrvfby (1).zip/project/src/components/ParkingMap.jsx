import { useState, useEffect } from 'react'

const ParkingMap = ({ height, parkingLots = [], interactive = false }) => {
  const [mapLoaded, setMapLoaded] = useState(false)
  
  // In a real application, this would use an actual map service like Google Maps or Mapbox
  // For demo purposes, we're using a placeholder
  useEffect(() => {
    // Simulate map loading
    const timer = setTimeout(() => {
      setMapLoaded(true)
    }, 1000)
    
    return () => clearTimeout(timer)
  }, [])

  return (
    <div style={{ height: height || '400px' }} className="relative bg-neutral-100 rounded-lg overflow-hidden">
      {!mapLoaded ? (
        <div className="h-full flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-neutral-200 border-t-primary-500 rounded-full animate-spin" />
        </div>
      ) : (
        <div className="relative h-full">
          {/* This would be replaced with an actual map component in a real app */}
          <div className="absolute inset-0 bg-neutral-200">
            <img 
              src="https://images.pexels.com/photos/6532373/pexels-photo-6532373.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
              alt="Map view of parking lots"
              className="w-full h-full object-cover opacity-50"
            />
          </div>
          
          {/* Parking spots overlay */}
          {parkingLots.length > 0 && (
            <div className="absolute inset-0">
              {parkingLots.map((lot) => (
                <div 
                  key={lot.id}
                  className={`absolute h-8 w-8 rounded-full flex items-center justify-center text-white text-xs font-medium cursor-pointer
                    ${lot.availableSpots > 0 ? 'bg-secondary-500' : 'bg-error'}
                  `}
                  style={{ 
                    left: `${lot.coordinates.x}%`, 
                    top: `${lot.coordinates.y}%`,
                    transform: 'translate(-50%, -50%)'
                  }}
                  title={`${lot.name}: ${lot.availableSpots} spots available`}
                >
                  {lot.availableSpots}
                </div>
              ))}
            </div>
          )}
          
          {/* For demo purposes, add some parking spot indicators */}
          <div className="absolute inset-0">
            <div 
              className="absolute h-8 w-8 bg-secondary-500 rounded-full flex items-center justify-center text-white text-xs font-medium cursor-pointer"
              style={{ left: '30%', top: '40%', transform: 'translate(-50%, -50%)' }}
              title="Downtown Parking: 15 spots available"
            >
              15
            </div>
            <div 
              className="absolute h-8 w-8 bg-secondary-500 rounded-full flex items-center justify-center text-white text-xs font-medium cursor-pointer"
              style={{ left: '60%', top: '30%', transform: 'translate(-50%, -50%)' }}
              title="Central Mall: 8 spots available"
            >
              8
            </div>
            <div 
              className="absolute h-8 w-8 bg-error rounded-full flex items-center justify-center text-white text-xs font-medium cursor-pointer"
              style={{ left: '70%', top: '60%', transform: 'translate(-50%, -50%)' }}
              title="City Park: 0 spots available"
            >
              0
            </div>
            <div 
              className="absolute h-8 w-8 bg-secondary-500 rounded-full flex items-center justify-center text-white text-xs font-medium cursor-pointer"
              style={{ left: '40%', top: '70%', transform: 'translate(-50%, -50%)' }}
              title="Stadium Parking: 22 spots available"
            >
              22
            </div>
          </div>
          
          {interactive && (
            <div className="absolute bottom-4 right-4 bg-white rounded-lg shadow-md p-3 flex flex-col space-y-2">
              <div className="flex items-center space-x-2">
                <div className="h-4 w-4 bg-secondary-500 rounded-full"></div>
                <span className="text-xs text-neutral-700">Available</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="h-4 w-4 bg-error rounded-full"></div>
                <span className="text-xs text-neutral-700">Full</span>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export default ParkingMap