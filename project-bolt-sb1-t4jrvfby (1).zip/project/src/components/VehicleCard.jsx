import { motion } from 'framer-motion'
import { FaEdit, FaTrash } from 'react-icons/fa'

const VehicleCard = ({ vehicle, onEdit, onDelete }) => {
  // For demo purposes
  const demoVehicle = vehicle || {
    id: '1',
    make: 'Tesla',
    model: 'Model 3',
    year: 2022,
    color: 'White',
    licensePlate: 'ABC-1234',
    type: 'Electric',
    imageUrl: 'https://images.pexels.com/photos/12309907/pexels-photo-12309907.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  }
  
  return (
    <motion.div
      whileHover={{ y: -5 }}
      transition={{ type: "spring", stiffness: 300 }}
      className="bg-white rounded-xl shadow-md overflow-hidden"
    >
      <div className="h-48 bg-neutral-200 relative">
        <img 
          src={demoVehicle.imageUrl} 
          alt={`${demoVehicle.make} ${demoVehicle.model}`} 
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-semibold text-neutral-900">
            {demoVehicle.make} {demoVehicle.model}
          </h3>
          <span className="text-xs font-medium px-2 py-1 bg-neutral-100 text-neutral-700 rounded-full">
            {demoVehicle.type}
          </span>
        </div>
        
        <p className="text-neutral-600 text-sm mb-4">
          {demoVehicle.year} · {demoVehicle.color} · {demoVehicle.licensePlate}
        </p>
        
        <div className="flex space-x-2">
          <button 
            onClick={onEdit}
            className="flex-1 py-2 flex justify-center items-center space-x-1 bg-neutral-100 text-neutral-700 hover:bg-neutral-200 rounded-lg transition-colors duration-200"
          >
            <FaEdit size={14} />
            <span>Edit</span>
          </button>
          <button 
            onClick={onDelete}
            className="flex-1 py-2 flex justify-center items-center space-x-1 bg-error bg-opacity-10 text-error hover:bg-opacity-20 rounded-lg transition-colors duration-200"
          >
            <FaTrash size={14} />
            <span>Delete</span>
          </button>
        </div>
      </div>
    </motion.div>
  )
}

export default VehicleCard