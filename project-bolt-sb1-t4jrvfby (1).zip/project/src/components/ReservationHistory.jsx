import { useState } from 'react'
import { FaSearch, FaFileDownload } from 'react-icons/fa'
import ReservationCard from './ReservationCard'

const ReservationHistory = ({ reservations: initialReservations = [] }) => {
  // For demo purposes
  const demoReservations = initialReservations.length > 0 ? initialReservations : [
    {
      id: '1',
      location: 'Downtown Parking Garage',
      spotNumber: 'A-15',
      dateTime: new Date(), // Today
      duration: 2, // hours
      vehicle: 'Tesla Model 3 (ABC-1234)',
      status: 'upcoming'
    },
    {
      id: '2',
      location: 'Mall Parking',
      spotNumber: 'B-22',
      dateTime: new Date(new Date().getTime() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
      duration: 3, // hours
      vehicle: 'Honda Civic (XYZ-5678)',
      status: 'completed'
    },
    {
      id: '3',
      location: 'Stadium Parking',
      spotNumber: 'C-05',
      dateTime: new Date(new Date().getTime() - 14 * 24 * 60 * 60 * 1000), // 14 days ago
      duration: 4, // hours
      vehicle: 'Tesla Model 3 (ABC-1234)',
      status: 'completed'
    }
  ]
  
  const [searchTerm, setSearchTerm] = useState('')
  const [filterStatus, setFilterStatus] = useState('all')
  
  const filteredReservations = demoReservations.filter(res => {
    const matchesSearch = 
      res.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      res.spotNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      res.vehicle.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesFilter = 
      filterStatus === 'all' || 
      res.status === filterStatus
    
    return matchesSearch && matchesFilter
  })
  
  const generateReceipt = (reservationId) => {
    // In a real app, this would generate and download a receipt
    alert(`Receipt for reservation ${reservationId} would be downloaded here.`)
  }

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between mb-6 space-y-4 sm:space-y-0 sm:space-x-4">
        <div className="relative flex-grow">
          <input
            type="text"
            placeholder="Search reservations..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input-field pl-10 w-full"
          />
          <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400" />
        </div>
        
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="input-field"
        >
          <option value="all">All Reservations</option>
          <option value="upcoming">Upcoming</option>
          <option value="completed">Completed</option>
          <option value="cancelled">Cancelled</option>
        </select>
      </div>
      
      {filteredReservations.length > 0 ? (
        <div className="space-y-4">
          {filteredReservations.map(reservation => (
            <div key={reservation.id} className="relative">
              <ReservationCard reservation={reservation} />
              
              {reservation.status === 'completed' && (
                <button
                  onClick={() => generateReceipt(reservation.id)}
                  className="absolute top-2 right-2 text-neutral-500 hover:text-primary-500"
                  title="Download Receipt"
                >
                  <FaFileDownload />
                </button>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8 bg-neutral-50 rounded-lg border border-neutral-200">
          <p className="text-neutral-600">No reservations found</p>
        </div>
      )}
    </div>
  )
}

export default ReservationHistory