import { motion } from 'framer-motion'
import { FaCalendarAlt, FaMapMarkerAlt, FaTicketAlt } from 'react-icons/fa'

const EventCard = ({ event, onSelect }) => {
  // For demo purposes
  const demoEvent = event || {
    id: '1',
    name: 'Summer Music Festival',
    location: 'City Park Amphitheater',
    date: 'Sat, Jun 15, 2023',
    time: '4:00 PM - 11:00 PM',
    type: 'Concert',
    imageUrl: 'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    availableSpots: 45
  }

  return (
    <motion.div
      whileHover={{ y: -5 }}
      transition={{ type: "spring", stiffness: 300 }}
      className="bg-white rounded-xl shadow-md overflow-hidden"
    >
      <div className="h-40 bg-neutral-200 relative">
        <img 
          src={demoEvent.imageUrl} 
          alt={demoEvent.name} 
          className="w-full h-full object-cover"
        />
        <div className="absolute top-0 left-0 right-0 p-2 bg-gradient-to-b from-black/70 to-transparent">
          <span className="text-xs font-medium px-2 py-1 bg-accent-500 text-white rounded-full">
            {demoEvent.type}
          </span>
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="text-lg font-semibold text-neutral-900 mb-2">{demoEvent.name}</h3>
        
        <div className="space-y-2 text-sm mb-4">
          <div className="flex items-center">
            <FaCalendarAlt className="text-neutral-500 mr-2 flex-shrink-0" />
            <span className="text-neutral-700">{demoEvent.date}</span>
          </div>
          
          <div className="flex items-center">
            <FaMapMarkerAlt className="text-neutral-500 mr-2 flex-shrink-0" />
            <span className="text-neutral-700">{demoEvent.location}</span>
          </div>
          
          <div className="flex items-center">
            <FaTicketAlt className="text-neutral-500 mr-2 flex-shrink-0" />
            <span className="text-neutral-700">{demoEvent.availableSpots} parking spots available</span>
          </div>
        </div>
        
        <button 
          onClick={() => onSelect(demoEvent)}
          className="btn-primary w-full"
        >
          Reserve Parking
        </button>
      </div>
    </motion.div>
  )
}

export default EventCard