import { motion } from 'framer-motion'
import { FaClock, FaMapMarkerAlt, FaCar } from 'react-icons/fa'

const ReservationCard = ({ reservation }) => {
  // For demo purposes
  const demoReservation = reservation || {
    id: '1',
    location: 'Downtown Parking Garage',
    spotNumber: 'A-15',
    dateTime: new Date(new Date().getTime() + 2 * 24 * 60 * 60 * 1000), // 2 days from now
    duration: 2, // hours
    vehicle: 'Tesla Model 3 (ABC-1234)'
  }
  
  // Format date for display
  const formatDate = (date) => {
    return new Intl.DateTimeFormat('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric'
    }).format(date)
  }
  
  const isUpcoming = demoReservation.dateTime > new Date()

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className={`p-4 border rounded-lg ${
        isUpcoming ? 'border-primary-200 bg-primary-50' : 'border-neutral-200 bg-neutral-50'
      }`}
    >
      <div className="flex justify-between items-start mb-2">
        <h3 className="font-medium text-neutral-900">
          Spot {demoReservation.spotNumber}
        </h3>
        {isUpcoming ? (
          <span className="text-xs font-medium px-2 py-1 bg-primary-100 text-primary-700 rounded-full">
            Upcoming
          </span>
        ) : (
          <span className="text-xs font-medium px-2 py-1 bg-neutral-200 text-neutral-700 rounded-full">
            Past
          </span>
        )}
      </div>
      
      <div className="space-y-2 text-sm">
        <div className="flex items-center">
          <FaMapMarkerAlt className="text-neutral-500 mr-2 flex-shrink-0" />
          <span className="text-neutral-700">{demoReservation.location}</span>
        </div>
        
        <div className="flex items-center">
          <FaClock className="text-neutral-500 mr-2 flex-shrink-0" />
          <span className="text-neutral-700">
            {formatDate(demoReservation.dateTime)} · {demoReservation.duration}h
          </span>
        </div>
        
        <div className="flex items-center">
          <FaCar className="text-neutral-500 mr-2 flex-shrink-0" />
          <span className="text-neutral-700">{demoReservation.vehicle}</span>
        </div>
      </div>
      
      {isUpcoming && (
        <div className="mt-4 flex space-x-2">
          <button className="btn-secondary text-sm py-1 px-3 flex-1">
            Cancel
          </button>
          <button className="btn-primary text-sm py-1 px-3 flex-1">
            View
          </button>
        </div>
      )}
    </motion.div>
  )
}

export default ReservationCard