import { useState } from 'react'
import { FaSave } from 'react-icons/fa'
import Alert from './common/Alert'
import { updateUserProfile } from '../services/apiService'

const ProfileForm = ({ profile, onUpdate }) => {
  // For demo purposes
  const demoProfile = profile || {
    name: 'John Doe',
    email: 'john.doe@example.com',
    phone: '+1 (555) 123-4567',
    address: '123 Main St, Cityville, ST 12345'
  }
  
  const [formData, setFormData] = useState({
    name: demoProfile.name || '',
    email: demoProfile.email || '',
    phone: demoProfile.phone || '',
    address: demoProfile.address || ''
  })
  
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)
  
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
    
    // Clear messages when user starts typing
    setSuccess(false)
    setError('')
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    
    // Simple validation
    if (!formData.name || !formData.email) {
      setError('Name and email are required')
      return
    }
    
    setLoading(true)
    setError('')
    setSuccess(false)
    
    try {
      const updatedProfile = await updateUserProfile(formData)
      onUpdate(updatedProfile)
      setSuccess(true)
    } catch (err) {
      console.error('Error updating profile:', err)
      setError('Failed to update profile. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      {error && <Alert type="error" message={error} className="mb-4" />}
      {success && <Alert type="success" message="Profile updated successfully!" className="mb-4" />}
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-neutral-700">
            Full Name
          </label>
          <input
            id="name"
            name="name"
            type="text"
            value={formData.name}
            onChange={handleChange}
            className="input-field mt-1"
            required
          />
        </div>
        
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-neutral-700">
            Email Address
          </label>
          <input
            id="email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            className="input-field mt-1"
            required
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
        <div>
          <label htmlFor="phone" className="block text-sm font-medium text-neutral-700">
            Phone Number
          </label>
          <input
            id="phone"
            name="phone"
            type="tel"
            value={formData.phone}
            onChange={handleChange}
            className="input-field mt-1"
          />
        </div>
        
        <div>
          <label htmlFor="address" className="block text-sm font-medium text-neutral-700">
            Address
          </label>
          <input
            id="address"
            name="address"
            type="text"
            value={formData.address}
            onChange={handleChange}
            className="input-field mt-1"
          />
        </div>
      </div>
      
      <div className="mt-6">
        <button 
          type="submit"
          disabled={loading}
          className="btn-primary flex items-center space-x-2"
        >
          {loading ? (
            <span className="inline-block h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
          ) : (
            <FaSave size={14} />
          )}
          <span>Save Changes</span>
        </button>
      </div>
    </form>
  )
}

export default ProfileForm