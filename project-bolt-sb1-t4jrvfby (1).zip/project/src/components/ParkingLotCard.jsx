import { motion } from 'framer-motion'
import { FaCar, FaWalking, FaChargingStation, FaUmbrella, FaWheelchair, FaShieldAlt } from 'react-icons/fa'

const ParkingLotCard = ({ parkingLot }) => {
  // For demo purposes since we don't have real data
  const demoLot = parkingLot || {
    id: '1',
    name: 'Downtown Parking Garage',
    address: '123 Main St, City Center',
    totalSpots: 50,
    availableSpots: 15,
    pricePerHour: 3.50,
    distance: 0.8,
    amenities: {
      electric: true,
      covered: true,
      handicap: true,
      security: true
    },
    imageUrl: 'https://images.pexels.com/photos/3004538/pexels-photo-3004538.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  }
  
  const availabilityPercentage = Math.round((demoLot.availableSpots / demoLot.totalSpots) * 100)

  return (
    <motion.div
      whileHover={{ y: -5 }}
      transition={{ type: "spring", stiffness: 300 }}
      className="bg-white rounded-xl shadow-md overflow-hidden"
    >
      <div className="h-32 bg-neutral-200 relative">
        <img 
          src={demoLot.imageUrl} 
          alt={demoLot.name} 
          className="w-full h-full object-cover"
        />
        <div className="absolute top-2 right-2 bg-white px-2 py-1 rounded-md text-xs font-medium">
          ${demoLot.pricePerHour.toFixed(2)}/hr
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="text-lg font-semibold text-neutral-900 mb-1">{demoLot.name}</h3>
        <p className="text-sm text-neutral-600 mb-3">{demoLot.address}</p>
        
        <div className="flex items-center mb-4">
          <div className="mr-4 flex items-center text-sm">
            <FaCar className="text-neutral-500 mr-1" />
            <span>{demoLot.availableSpots}/{demoLot.totalSpots} spots</span>
          </div>
          <div className="flex items-center text-sm">
            <FaWalking className="text-neutral-500 mr-1" />
            <span>{demoLot.distance} km</span>
          </div>
        </div>
        
        <div className="mb-4">
          <div className="w-full bg-neutral-200 rounded-full h-2">
            <div 
              className={`h-2 rounded-full ${
                availabilityPercentage > 60 
                  ? 'bg-secondary-500' 
                  : availabilityPercentage > 30 
                    ? 'bg-warning' 
                    : 'bg-error'
              }`}
              style={{ width: `${availabilityPercentage}%` }}
            ></div>
          </div>
          <p className="text-xs text-neutral-500 mt-1">
            {availabilityPercentage}% available
          </p>
        </div>
        
        <div className="flex flex-wrap gap-2 mb-4">
          {demoLot.amenities.electric && (
            <div className="bg-neutral-100 px-2 py-1 rounded-md text-xs flex items-center">
              <FaChargingStation className="text-neutral-700 mr-1" size={12} />
              <span>Charging</span>
            </div>
          )}
          {demoLot.amenities.covered && (
            <div className="bg-neutral-100 px-2 py-1 rounded-md text-xs flex items-center">
              <FaUmbrella className="text-neutral-700 mr-1" size={12} />
              <span>Covered</span>
            </div>
          )}
          {demoLot.amenities.handicap && (
            <div className="bg-neutral-100 px-2 py-1 rounded-md text-xs flex items-center">
              <FaWheelchair className="text-neutral-700 mr-1" size={12} />
              <span>Accessible</span>
            </div>
          )}
          {demoLot.amenities.security && (
            <div className="bg-neutral-100 px-2 py-1 rounded-md text-xs flex items-center">
              <FaShieldAlt className="text-neutral-700 mr-1" size={12} />
              <span>Security</span>
            </div>
          )}
        </div>
        
        <button className="btn-primary w-full">Reserve Spot</button>
      </div>
    </motion.div>
  )
}

export default ParkingLotCard