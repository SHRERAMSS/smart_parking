import { useState } from 'react'
import { FaSave, FaTimes } from 'react-icons/fa'
import Alert from './common/Alert'
import { saveVehicle } from '../services/apiService'

const VehicleForm = ({ vehicle, onSave, onCancel }) => {
  const [formData, setFormData] = useState({
    make: vehicle?.make || '',
    model: vehicle?.model || '',
    year: vehicle?.year || new Date().getFullYear(),
    color: vehicle?.color || '',
    licensePlate: vehicle?.licensePlate || '',
    type: vehicle?.type || 'Standard',
    imageUrl: vehicle?.imageUrl || ''
  })
  
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    
    // Simple validation
    if (!formData.make || !formData.model || !formData.licensePlate) {
      setError('Please fill in all required fields')
      return
    }
    
    setLoading(true)
    setError('')
    
    try {
      // If editing existing vehicle, include the ID
      const vehicleData = vehicle?.id
        ? { ...formData, id: vehicle.id }
        : { ...formData, id: Date.now().toString() } // For demo purposes
      
      const savedVehicle = await saveVehicle(vehicleData)
      onSave(savedVehicle)
    } catch (err) {
      console.error('Error saving vehicle:', err)
      setError('Failed to save vehicle. Please try again.')
    } finally {
      setLoading(false)
    }
  }
  
  return (
    <form onSubmit={handleSubmit} className="p-6">
      {error && <Alert type="error" message={error} className="mb-4" />}
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
        <div>
          <label htmlFor="make" className="block text-sm font-medium text-neutral-700">
            Make *
          </label>
          <input
            id="make"
            name="make"
            type="text"
            value={formData.make}
            onChange={handleChange}
            className="input-field mt-1"
            required
          />
        </div>
        
        <div>
          <label htmlFor="model" className="block text-sm font-medium text-neutral-700">
            Model *
          </label>
          <input
            id="model"
            name="model"
            type="text"
            value={formData.model}
            onChange={handleChange}
            className="input-field mt-1"
            required
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
        <div>
          <label htmlFor="year" className="block text-sm font-medium text-neutral-700">
            Year
          </label>
          <input
            id="year"
            name="year"
            type="number"
            min="1900"
            max={new Date().getFullYear() + 1}
            value={formData.year}
            onChange={handleChange}
            className="input-field mt-1"
          />
        </div>
        
        <div>
          <label htmlFor="color" className="block text-sm font-medium text-neutral-700">
            Color
          </label>
          <input
            id="color"
            name="color"
            type="text"
            value={formData.color}
            onChange={handleChange}
            className="input-field mt-1"
          />
        </div>
        
        <div>
          <label htmlFor="type" className="block text-sm font-medium text-neutral-700">
            Vehicle Type
          </label>
          <select
            id="type"
            name="type"
            value={formData.type}
            onChange={handleChange}
            className="input-field mt-1"
          >
            <option value="Standard">Standard</option>
            <option value="Compact">Compact</option>
            <option value="SUV">SUV</option>
            <option value="Electric">Electric</option>
            <option value="Truck">Truck</option>
          </select>
        </div>
      </div>
      
      <div className="mb-4">
        <label htmlFor="licensePlate" className="block text-sm font-medium text-neutral-700">
          License Plate *
        </label>
        <input
          id="licensePlate"
          name="licensePlate"
          type="text"
          value={formData.licensePlate}
          onChange={handleChange}
          className="input-field mt-1"
          required
        />
      </div>
      
      <div className="mb-6">
        <label htmlFor="imageUrl" className="block text-sm font-medium text-neutral-700">
          Vehicle Image URL
        </label>
        <input
          id="imageUrl"
          name="imageUrl"
          type="url"
          value={formData.imageUrl}
          onChange={handleChange}
          className="input-field mt-1"
          placeholder="https://example.com/image.jpg"
        />
        <p className="mt-1 text-xs text-neutral-500">
          Provide a URL for an image of your vehicle (optional)
        </p>
      </div>
      
      <div className="flex justify-end space-x-3">
        <button 
          type="button"
          onClick={onCancel}
          className="flex items-center space-x-1 px-4 py-2 border border-neutral-300 rounded-lg shadow-sm text-neutral-700 bg-white hover:bg-neutral-50"
        >
          <FaTimes size={14} />
          <span>Cancel</span>
        </button>
        
        <button 
          type="submit"
          disabled={loading}
          className="btn-primary flex items-center space-x-1"
        >
          {loading ? (
            <span className="inline-block h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
          ) : (
            <FaSave size={14} />
          )}
          <span>{vehicle ? 'Update' : 'Save'} Vehicle</span>
        </button>
      </div>
    </form>
  )
}

export default VehicleForm