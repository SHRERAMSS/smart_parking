import { useState } from 'react'
import { FaKey } from 'react-icons/fa'
import Alert from './common/Alert'
import { updatePassword } from '../services/apiService'

const PasswordForm = () => {
  const [formData, setFormData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  })
  
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)
  
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
    
    // Clear messages when user starts typing
    setSuccess(false)
    setError('')
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    
    // Validation
    if (!formData.currentPassword || !formData.newPassword || !formData.confirmPassword) {
      setError('All fields are required')
      return
    }
    
    if (formData.newPassword !== formData.confirmPassword) {
      setError('New passwords do not match')
      return
    }
    
    if (formData.newPassword.length < 6) {
      setError('New password must be at least 6 characters long')
      return
    }
    
    setLoading(true)
    setError('')
    setSuccess(false)
    
    try {
      await updatePassword(formData)
      setSuccess(true)
      
      // Clear form
      setFormData({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      })
    } catch (err) {
      console.error('Error updating password:', err)
      setError('Failed to update password. Please check your current password and try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      {error && <Alert type="error" message={error} className="mb-4" />}
      {success && <Alert type="success" message="Password updated successfully!" className="mb-4" />}
      
      <div className="mb-4">
        <label htmlFor="currentPassword" className="block text-sm font-medium text-neutral-700">
          Current Password
        </label>
        <input
          id="currentPassword"
          name="currentPassword"
          type="password"
          value={formData.currentPassword}
          onChange={handleChange}
          className="input-field mt-1"
          required
        />
      </div>
      
      <div className="mb-4">
        <label htmlFor="newPassword" className="block text-sm font-medium text-neutral-700">
          New Password
        </label>
        <input
          id="newPassword"
          name="newPassword"
          type="password"
          value={formData.newPassword}
          onChange={handleChange}
          className="input-field mt-1"
          required
        />
        <p className="mt-1 text-xs text-neutral-500">
          Must be at least 6 characters long
        </p>
      </div>
      
      <div className="mb-6">
        <label htmlFor="confirmPassword" className="block text-sm font-medium text-neutral-700">
          Confirm New Password
        </label>
        <input
          id="confirmPassword"
          name="confirmPassword"
          type="password"
          value={formData.confirmPassword}
          onChange={handleChange}
          className="input-field mt-1"
          required
        />
      </div>
      
      <div className="mt-6">
        <button 
          type="submit"
          disabled={loading}
          className="btn-primary flex items-center space-x-2"
        >
          {loading ? (
            <span className="inline-block h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
          ) : (
            <FaKey size={14} />
          )}
          <span>Update Password</span>
        </button>
      </div>
    </form>
  )
}

export default PasswordForm