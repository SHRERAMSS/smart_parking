import { createContext, useContext, useState, useEffect } from 'react'
import axios from 'axios'

const API_URL = 'http://localhost:5000/api'
const TOKEN_KEY = 'smart_parking_token'

const AuthContext = createContext()

export const useAuth = () => useContext(AuthContext)

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  // Check if user is logged in on page load
  useEffect(() => {
    const verifyToken = async () => {
      const token = localStorage.getItem(TOKEN_KEY)
      
      if (!token) {
        setLoading(false)
        return
      }
      
      try {
        const response = await axios.get(`${API_URL}/auth/verify`, {
          headers: { Authorization: `Bearer ${token}` }
        })
        
        if (response.data.user) {
          setUser(response.data.user)
        }
      } catch (err) {
        console.error('Token verification failed:', err)
        localStorage.removeItem(TOKEN_KEY)
      } finally {
        setLoading(false)
      }
    }
    
    verifyToken()
  }, [])

  // Register a new user
  const register = async (userData) => {
    setLoading(true)
    setError(null)
    
    try {
      const response = await axios.post(`${API_URL}/auth/register`, userData)
      const { token, user } = response.data
      
      localStorage.setItem(TOKEN_KEY, token)
      setUser(user)
      
      return user
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed')
      throw err
    } finally {
      setLoading(false)
    }
  }

  // Login an existing user
  const login = async (credentials) => {
    setLoading(true)
    setError(null)
    
    try {
      const response = await axios.post(`${API_URL}/auth/login`, credentials)
      const { token, user } = response.data
      
      localStorage.setItem(TOKEN_KEY, token)
      setUser(user)
      
      return user
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed')
      throw err
    } finally {
      setLoading(false)
    }
  }

  // Logout the current user
  const logout = () => {
    localStorage.removeItem(TOKEN_KEY)
    setUser(null)
  }

  // Clear any auth errors
  const clearError = () => setError(null)

  const value = {
    user,
    loading,
    error,
    register,
    login,
    logout,
    clearError,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}