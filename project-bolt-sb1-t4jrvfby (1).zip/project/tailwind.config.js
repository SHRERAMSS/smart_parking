/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#e6f1ff',
          100: '#cce3ff',
          200: '#99c8ff',
          300: '#66acff',
          400: '#3391ff',
          500: '#0A84FF', // Primary blue
          600: '#0969cc',
          700: '#074f99',
          800: '#053466',
          900: '#021a33',
        },
        secondary: {
          50: '#e8fef0',
          100: '#d1fde1',
          200: '#a3fbc3',
          300: '#75f9a5',
          400: '#47f787',
          500: '#30D158', // Secondary green
          600: '#26a746',
          700: '#1d7d35',
          800: '#135423',
          900: '#092a12',
        },
        accent: {
          50: '#f7effd',
          100: '#efdffc',
          200: '#dfbff9',
          300: '#d09ff6',
          400: '#c07ff3',
          500: '#BF5AF2', // Accent purple
          600: '#9848c2',
          700: '#723691',
          800: '#4c2461',
          900: '#261230',
        },
        warning: '#FF9F0A',
        error: '#FF453A',
        neutral: {
          50: '#f9fafb',
          100: '#f3f4f6',
          200: '#e5e7eb',
          300: '#d1d5db',
          400: '#9ca3af',
          500: '#6b7280',
          600: '#4b5563',
          700: '#374151',
          800: '#1f2937',
          900: '#111827',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      spacing: {
        '1': '8px',
        '2': '16px',
        '3': '24px',
        '4': '32px',
        '5': '40px',
        '6': '48px',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      }
    },
  },
  plugins: [],
}